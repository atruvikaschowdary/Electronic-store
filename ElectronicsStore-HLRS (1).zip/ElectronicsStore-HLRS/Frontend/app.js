var con = require('./connection');
const mysql = require('mysql');

const bodyParser = require('body-parser');
const express = require('express');
const path = require('path');
const { Router } = require('express');



const session = require('express-session');


const app = express();


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.use(express.urlencoded( {extended :false}));


app.use(express.static(path.join(__dirname, 'public')));




app.get('/', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/reg.html'));
});

app.post('/',function(req,res){
    console.log(req.body);
    var name = req.body.name;
    var mobile = req.body.mobile;
    var email = req.body.email;
    var password = req.body.password;

    con.connect(function(error){
        if(error) throw error;
        var sql = "INSERT INTO data(name,mobile,email,password) VALUES('"+name+"','"+mobile+"','"+email+"','"+password+"')";
        con.query(sql,function(error,result){
            if(error) throw error;
            res.redirect('/public/login.html');

        })
    })


})

app.get('/public/login.html', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/login.html'));
});



///Login code


const connection = mysql.createConnection({
	host     : 'localhost',
	user     : 'root',
	password : '',
	database : 'test'
});






app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'static')));

// http://localhost:3000/
app.get('/', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/login.html'));
});

// http://localhost:3000/auth
app.post('/auth', function(request, response) {
	// Capture the input fields
	let email = request.body.email;
	let password = request.body.password;
	console.log(email);
	console.log(password);

	// Ensure the input fields exists and are not empty
	if (email && password) {
		// Execute SQL query that'll select the account from the database based on the specified username and password
		connection.query('SELECT * FROM data WHERE email = ? AND password = ?', [email, password], function(error, results, fields) {
			// If there is an issue with the query, output the error
			if (error) throw error;
			// If the account exists
			if (results.length > 0) {
				// Authenticate the user
				request.session.loggedin = true;
				request.session.email = email;
				// Redirect to home page
				response.redirect('/public/productsmain.html');
			} else {
				response.send('Incorrect Username and/or Password!');
			}			
			response.end();
		});
	} else {
		response.send('Please enter Username and Password!');
		response.end();
	}
});



// http://localhost:3000/home
app.get('/public/productsmain.html', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/productsmain.html'));
});



app.get('/public/product1.html', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/product1.html'));
});


app.get('/public/product2.html', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/product2.html'));
});


app.get('/public/laptop-ui/index.html', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/laptop-ui/index.html'));
});


app.get('/public/product3.html', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/product3.html'));
});

app.get('/public/popup.html', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/popup.html'));
});


app.get('/public/laptop-ui/popup.html', function(request, response) {
	// Render login template
	response.sendFile(path.join(__dirname + '/public/laptop-ui/popup.html'));
});









app.listen(3000,() =>{
    console.log('server is running on port 3000');
});

